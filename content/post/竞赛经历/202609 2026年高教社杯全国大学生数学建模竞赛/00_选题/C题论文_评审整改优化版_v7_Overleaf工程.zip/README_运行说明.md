# C题支撑材料运行说明

## 目录
- `data/`：放置附件1.xlsx、附件2.xlsx、附件3.xlsx、附件4.xlsx。
- `code/`：完整 Python 源程序。
- `results/`：运行后生成 result1.xlsx、result2.xlsx、result3.xlsx、result4-2.xlsx、result4-3.xlsx。
- `models/`：运行时生成的 Q2-Q4 PeriodResult 缓存，供费用复核和结算口径分析使用。

## 环境
推荐 Python 3.11 或更高版本。

```bash
pip install -r requirements.txt
```

## 一键复现正式结果
在项目根目录运行：

```bash
python code/run_all.py --data-dir ./data --output-dir ./results --cache-dir ./models
```

脚本依次求解 Q1、Q2、Q3、Q4-2、Q4-3，保持 Q2-Q4 跨日 SOC 连续，并生成五个正式结果工作簿。

## 提交前审计

```bash
python code/review_audit.py
```

若同时保留官方空白结果模板，可进一步执行：

```bash
python code/review_audit.py --template-dir ./data/template --result-dir ./results
```

审计项目包括 Q3/Q4-3 的 0/6/12/18 发布时间映射、物理时间槽、紧急购电动态扩行默认设置和调整费用自检。

## 说明
正式运行路径不启用 Oracle、CVaR 或额外二进制互斥开关。Excel 的正式时间表头按物理区间 `0:00-0:10` 至 `23:50-24:00` 输出；附件1/2/4的右端点标签只用于输入读取。
