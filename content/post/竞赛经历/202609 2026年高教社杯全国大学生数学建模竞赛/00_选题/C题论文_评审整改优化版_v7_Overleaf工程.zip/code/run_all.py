# -*- coding: utf-8 -*-
"""
run_all.py

正式复现入口：从附件1-4读取数据，依次求解 Q1、Q2、Q3、Q4-2、Q4-3，
并输出题目要求的五个 result*.xlsx。

示例：
    python code/run_all.py --data-dir ./data --output-dir ./results

说明：
- data-dir 中需包含 附件1.xlsx ... 附件4.xlsx；
- Q2-Q4 默认从 2025-01-01 开始顺序模拟，2025-02-01 起写入正式结果；
- 五个结果文件由 result_writer.write_all_results 统一写出并回读校验；
- 本脚本只串联正式模型，不启用 Oracle、CVaR、MILP 互斥或敏感性扩展。
"""
from __future__ import annotations

import argparse
import pickle
from pathlib import Path

from config import ProjectConfig
from data_loader import load_all
from question1_solver import Question1Solver
from question2_solver import Question2Solver
from question3_solver import Question3Solver
from question4_solver import Question4Solver
from result_writer import write_all_results


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="C题 Q1-Q4 正式结果一键复现")
    parser.add_argument("--data-dir", default="data", help="附件1-4所在目录")
    parser.add_argument("--output-dir", default="results", help="五个result文件输出目录")
    parser.add_argument("--cache-dir", default="models", help="可选中间PeriodResult缓存目录")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data_dir = Path(args.data_dir)
    output_dir = Path(args.output_dir)
    cache_dir = Path(args.cache_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    cache_dir.mkdir(parents=True, exist_ok=True)

    config = ProjectConfig(data_dir=data_dir)
    bundle = load_all(config)

    print("[1/5] Q1", flush=True)
    q1 = Question1Solver(attachment1=bundle.attachment1, config=config).solve()

    print("[2/5] Q2", flush=True)
    q2_solver = Question2Solver(
        attachment1=bundle.attachment1,
        attachment2=bundle.attachment2,
        config=config,
    )
    q2 = q2_solver.solve_period()

    print("[3/5] Q3", flush=True)
    q3_solver = Question3Solver(
        attachment1=bundle.attachment1,
        attachment2=bundle.attachment2,
        attachment3=bundle.attachment3,
        config=config,
    )
    q3 = q3_solver.solve_period()

    print("[4/5] Q4-2", flush=True)
    q4_solver = Question4Solver(
        attachment1=bundle.attachment1,
        attachment2=bundle.attachment2,
        attachment3=bundle.attachment3,
        attachment4=bundle.attachment4,
        config=config,
    )
    q42 = q4_solver.solve_q4_2_period()

    print("[5/5] Q4-3", flush=True)
    q43 = q4_solver.solve_q4_3_period()

    # 保存可复核的PeriodResult，供费用审计/结算口径分析复用。
    for name, obj in {
        "q2_period.pkl": q2,
        "q3_period.pkl": q3,
        "q4_2_period.pkl": q42,
        "q4_3_period.pkl": q43,
    }.items():
        with (cache_dir / name).open("wb") as f:
            pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)

    outputs = write_all_results(
        result1=q1,
        result2_period=q2,
        result3_period=q3,
        result4_2_period=q42,
        result4_3_period=q43,
        output_dir=output_dir,
        strict_max_three_events=False,
        config=config,
    )

    print("\n正式结果已生成并回读校验：")
    for filename, (path, report) in outputs.items():
        passed = bool(report["passed"].all()) if "passed" in report.columns else True
        print(f"  {filename}: {path}  passed={passed}")


if __name__ == "__main__":
    main()
