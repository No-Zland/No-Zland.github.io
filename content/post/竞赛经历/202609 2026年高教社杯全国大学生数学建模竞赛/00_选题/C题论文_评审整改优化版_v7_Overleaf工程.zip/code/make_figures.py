# -*- coding: utf-8 -*-
from pathlib import Path
import re
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.dates import MonthLocator, DateFormatter
from matplotlib.ticker import MaxNLocator

ROOT = Path(__file__).parent
DATA = ROOT / 'data'
RES = ROOT / 'results'
OUT = ROOT / 'figures'
OUT.mkdir(exist_ok=True)

# 与论文宋体体系一致：优先使用系统宋体；服务器无 SimSun 时退回 FandolSong/Noto Serif CJK。
def choose_song_font():
    candidates = ['SimSun', '宋体', 'Songti SC', 'STSong', 'FandolSong', 'Noto Serif CJK SC']
    for name in candidates:
        try:
            font_manager.findfont(name, fallback_to_default=False)
            return name
        except Exception:
            pass
    local_candidates = [
        ROOT / 'fonts' / 'simsun.ttc',
        Path('/usr/share/texlive/texmf-dist/fonts/opentype/public/fandol/FandolSong-Regular.otf'),
    ]
    for fp in local_candidates:
        if fp.exists():
            font_manager.fontManager.addfont(str(fp))
            return font_manager.FontProperties(fname=str(fp)).get_name()
    return 'serif'

FONT = choose_song_font()

mpl.rcParams.update({
    'font.family': FONT,
    'axes.unicode_minus': False,
    'font.size': 8.5,
    'axes.labelsize': 8.5,
    'axes.titlesize': 9.5,
    'legend.fontsize': 7.5,
    'xtick.labelsize': 7.5,
    'ytick.labelsize': 7.5,
    'axes.linewidth': 0.75,
    'lines.linewidth': 1.35,
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
    'savefig.facecolor': 'white',
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
    'svg.fonttype': 'none',
})

# 用户推荐配色表中的主力色
C = {
    'deep': '#3F3770',
    'blue': '#036EAD',
    'midblue': '#3573A1',
    'lightblue': '#A3D8F4',
    'orange': '#F3962F',
    'coral': '#F57065',
    'rose': '#D6456C',
    'slate': '#8798C9',
    'gray': '#666666',
    'lightgray': '#D9D9D9',
    'green': '#4E8B57',
}

def style(ax, grid=True):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.tick_params(direction='out', length=3, width=.7)
    if grid:
        ax.grid(axis='y', color=C['lightgray'], lw=.5, alpha=.55, zorder=0)

def panel(ax, label):
    ax.text(-0.10, 1.04, label, transform=ax.transAxes, fontweight='bold', fontsize=10, va='bottom')

def save(fig, name):
    fig.savefig(OUT/f'{name}.pdf', bbox_inches='tight', pad_inches=.03)
    fig.savefig(OUT/f'{name}.png', dpi=450, bbox_inches='tight', pad_inches=.03)
    fig.savefig(OUT/f'{name}.svg', bbox_inches='tight', pad_inches=.03)
    plt.close(fig)

def time_x(): return (np.arange(144)+0.5)/6

def read_wide(path, sheet, date):
    df=pd.read_excel(path,sheet_name=sheet)
    ds=pd.to_datetime(df.iloc[:,0],errors='coerce').dt.normalize()
    target=pd.Timestamp(date).normalize()
    row=df.loc[ds==target].iloc[0,1:145]
    return pd.to_numeric(row,errors='coerce').to_numpy(float)

def read_result_matrix(path, sheet):
    df=pd.read_excel(path,sheet_name=sheet)
    dates=pd.to_datetime(df.iloc[:,0],errors='coerce').dt.normalize()
    valid=dates.notna()
    mat=df.loc[valid,df.columns[1:145]].apply(pd.to_numeric,errors='coerce').to_numpy(float)
    return pd.DatetimeIndex(dates[valid]),mat,df.loc[valid].reset_index(drop=True)

def read_result_day(path, sheet, date):
    dates,mat,_=read_result_matrix(path,sheet)
    idx=np.where(dates==pd.Timestamp(date).normalize())[0]
    if len(idx)!=1: raise ValueError(date)
    return mat[idx[0]]

def daily_emergency(path):
    # 完整日期由计划购电量表给出；无紧急购电的日期补0
    all_dates=pd.to_datetime(pd.read_excel(path,sheet_name='计划购电量').iloc[:,0],errors='coerce').dropna().dt.normalize()
    em=pd.read_excel(path,sheet_name='紧急购电量').iloc[:,:3].copy()
    em.columns=['日期','时段','购电量']
    em['日期']=pd.to_datetime(em['日期'].ffill(),errors='coerce').dt.normalize()
    em['购电量']=pd.to_numeric(em['购电量'],errors='coerce')
    em=em.dropna(subset=['日期','购电量'])
    g=em.groupby('日期').agg(紧急购电量=('购电量','sum'),区间块数=('购电量','size'))
    g=g.reindex(pd.DatetimeIndex(all_dates),fill_value=0)
    g.index.name='日期'
    return g

# ---------- 图：基础数据特征 ----------
att1=pd.read_excel(DATA/'附件1.xlsx')
price=pd.to_numeric(att1.iloc[:144,1],errors='coerce').to_numpy(float)
load_kw=pd.to_numeric(att1.iloc[:144,2],errors='coerce').to_numpy(float)
pv_kw=pd.to_numeric(att1.iloc[:144,3],errors='coerce').to_numpy(float)
x=time_x()
fig,axs=plt.subplots(1,3,figsize=(7.1,2.55),gridspec_kw={'wspace':.30})
for a in axs: style(a); a.set_xlim(0,24); a.set_xticks([0,6,12,18,24]); a.set_xlabel('时刻 / h')
axs[0].plot(x,load_kw,color=C['blue']); axs[0].set_ylabel('功率 / kW'); axs[0].set_title('负荷'); panel(axs[0],'(a)')
axs[1].plot(x,pv_kw,color=C['orange']); axs[1].set_ylabel('功率 / kW'); axs[1].set_title('光伏预测'); panel(axs[1],'(b)')
axs[2].step(x,price,where='mid',color=C['deep'],ls='--'); axs[2].set_ylabel('电价 / (元·kWh$^{-1}$)'); axs[2].set_title('分时电价'); panel(axs[2],'(c)')
save(fig,'data_profiles')

# ---------- Q1 ----------
q1=pd.read_excel(RES/'result1.xlsx',sheet_name='计划购电量')
qbuy=pd.to_numeric(q1.iloc[:144,1],errors='coerce').to_numpy(float)
load_kwh=load_kw/6; pv_kwh=pv_kw/6
surplus=qbuy+pv_kwh-load_kwh
qch=np.clip(surplus,0,None); qdis=np.clip(-surplus,0,None)
soc=np.empty(145); soc[0]=6000
for k in range(144): soc[k+1]=soc[k]+.9*qch[k]-qdis[k]/.9
fig,axs=plt.subplots(2,1,figsize=(7.1,4.6),gridspec_kw={'hspace':.33})
style(axs[0]); panel(axs[0],'(a)')
axs[0].bar(x,qch,width=.145,color=C['lightblue'],edgecolor='none',label='充电量',zorder=2)
axs[0].bar(x,-qdis,width=.145,color=C['coral'],edgecolor='none',label='放电量',zorder=2)
axs[0].plot(x,qbuy,color=C['blue'],lw=1.25,label='正常购电量',zorder=3)
axs[0].axhline(0,color='#444',lw=.6); axs[0].set_xlim(0,24); axs[0].set_xticks([0,4,8,12,16,20,24]); axs[0].set_ylabel('区间电量 / kWh'); axs[0].set_xlabel('时刻 / h')
axs[0].legend(ncol=3,frameon=False,loc='upper center')
style(axs[1]); panel(axs[1],'(b)')
xb=np.arange(145)/6
axs[1].fill_between(xb,1200,10800,color=C['lightblue'],alpha=.18,label='允许区间')
axs[1].plot(xb,soc,color=C['deep'],lw=1.5,label='SOC')
axs[1].axhline(1200,color=C['gray'],ls='--',lw=.8); axs[1].axhline(10800,color=C['gray'],ls='--',lw=.8)
axs[1].set_xlim(0,24); axs[1].set_ylim(0,12000); axs[1].set_xticks([0,4,8,12,16,20,24]); axs[1].set_ylabel('储能电量 / kWh'); axs[1].set_xlabel('时刻 / h'); axs[1].legend(frameon=False,loc='upper right')
save(fig,'q1_dispatch')

# ---------- Q2 annual risk ----------
q2e=daily_emergency(RES/'result2.xlsx')
fig,axs=plt.subplots(2,2,figsize=(7.1,5.1),gridspec_kw={'hspace':.42,'wspace':.32})
for a,l in zip(axs.flat,['(a)','(b)','(c)','(d)']): style(a); panel(a,l)
axs[0,0].plot(q2e.index,q2e['紧急购电量']/1000,color=C['blue'],lw=.9)
axs[0,0].set_ylabel('日紧急购电量 / MWh'); axs[0,0].xaxis.set_major_locator(MonthLocator(interval=2)); axs[0,0].xaxis.set_major_formatter(DateFormatter('%m月'))
vals=np.sort(q2e['紧急购电量'].to_numpy(float)/1000); yy=np.arange(1,len(vals)+1)/len(vals)
axs[0,1].plot(vals,yy,color=C['rose']); axs[0,1].set_xlabel('日紧急购电量 / MWh'); axs[0,1].set_ylabel('经验累积概率'); axs[0,1].set_ylim(0,1.02)
axs[1,0].scatter(q2e['区间块数'],q2e['紧急购电量']/1000,s=11,alpha=.45,color=C['midblue'],edgecolors='none')
axs[1,0].set_xlabel('日紧急购电区间块数 / 个'); axs[1,0].set_ylabel('日紧急购电量 / MWh')
monthly=(q2e['紧急购电量']/1000).groupby(q2e.index.month).sum()
axs[1,1].bar(monthly.index,monthly.values,color=C['slate'],width=.72); axs[1,1].set_xlabel('月份'); axs[1,1].set_ylabel('月紧急购电量 / MWh'); axs[1,1].set_xticks(range(2,13,2))
save(fig,'q2_risk')

# ---------- Q3 ----------
d3,p0,df0 = None,None,None
dates3,p3,dfp=read_result_matrix(RES/'result3.xlsx','计划购电量')
dates3f,f3,dff=read_result_matrix(RES/'result3.xlsx','调整购电量')
delta=f3-p3
absday=np.nansum(np.abs(delta),axis=1)
rep_idx=int(np.nanargmax(absday)); rep_date=dates3[rep_idx]
q2daily=daily_emergency(RES/'result2.xlsx'); q3daily=daily_emergency(RES/'result3.xlsx')
fig=plt.figure(figsize=(7.1,6.15))
gs=fig.add_gridspec(2,2,height_ratios=[.9,1.1],hspace=.38,wspace=.33)
a=fig.add_subplot(gs[0,0]); style(a); panel(a,'(a)')
a.plot(x,p3[rep_idx],color=C['gray'],ls='--',label='0:00 原计划')
a.plot(x,f3[rep_idx],color=C['blue'],label='最终有效计划')
a.fill_between(x,p3[rep_idx],f3[rep_idx],color=C['lightblue'],alpha=.35)
a.set_xlim(0,24); a.set_xticks([0,6,12,18,24]); a.set_xlabel('时刻 / h'); a.set_ylabel('购电量 / (kWh/10 min)'); a.legend(frameon=False)
a.text(.02,.93,f'代表日：{rep_date:%m月%d日}',transform=a.transAxes,fontsize=7.2)
a=fig.add_subplot(gs[0,1]); style(a); panel(a,'(b)')
a.plot(dates3,absday/1000,color=C['orange'],lw=.85); a.set_ylabel('日绝对调整量 / MWh'); a.xaxis.set_major_locator(MonthLocator(interval=2)); a.xaxis.set_major_formatter(DateFormatter('%m月'))
a=fig.add_subplot(gs[1,0]); panel(a,'(c)')
finite=np.abs(delta[np.isfinite(delta)]); vmax=np.percentile(finite,98) if len(finite) else 1
cmap=mpl.colors.LinearSegmentedColormap.from_list('adj',[C['blue'],'white',C['rose']])
im=a.imshow(delta,aspect='auto',interpolation='nearest',cmap=cmap,vmin=-vmax,vmax=vmax,origin='upper')
a.set_xticks(np.arange(0,145,24)); a.set_xticklabels(['0','4','8','12','16','20','24']); a.set_xlabel('时刻 / h'); a.set_ylabel('月份')
pos=[]; lab=[]; seen=set()
for i,d in enumerate(dates3):
    if d.month not in seen: seen.add(d.month); pos.append(i); lab.append(f'{d.month}月')
a.set_yticks(pos); a.set_yticklabels(lab); a.spines['top'].set_visible(False); a.spines['right'].set_visible(False)
cb=fig.colorbar(im,ax=a,pad=.02,fraction=.05); cb.set_label('调整量 / kWh')
a=fig.add_subplot(gs[1,1]); style(a); panel(a,'(d)')
pair=pd.DataFrame({'Q2':q2daily['紧急购电量']/1000,'Q3':q3daily['紧急购电量']/1000}).dropna(); m=max(pair.max())
a.scatter(pair['Q2'],pair['Q3'],s=10,alpha=.42,color=C['slate'],edgecolors='none'); a.plot([0,m],[0,m],ls='--',color=C['gray'],lw=.8)
a.set_xlabel('Q2 日紧急购电量 / MWh'); a.set_ylabel('Q3 日紧急购电量 / MWh'); a.set_xlim(0,m*1.03); a.set_ylim(0,m*1.03)
save(fig,'q3_update')

# ---------- Q4 ----------
dates42,q42,df42=read_result_matrix(RES/'result4-2.xlsx','计划购电量')
dates43,q43,df43=read_result_matrix(RES/'result4-3.xlsx','调整购电量')
rep_date=pd.Timestamp('2025-08-25')
i42=np.where(dates42==rep_date)[0][0]; i43=np.where(dates43==rep_date)[0][0]
price4=read_wide(DATA/'附件4.xlsx','Sheet1',rep_date)
q4e2=daily_emergency(RES/'result4-2.xlsx'); q4e3=daily_emergency(RES/'result4-3.xlsx')
summary=[]
for name,path,sheet in [('Q2',RES/'result2.xlsx','计划购电量'),('Q3',RES/'result3.xlsx','调整购电量'),('Q4-2',RES/'result4-2.xlsx','计划购电量'),('Q4-3',RES/'result4-3.xlsx','调整购电量')]:
    df=pd.read_excel(path,sheet_name=sheet); cost=pd.to_numeric(df['全天购电费'],errors='coerce').sum()/1e4
    em=daily_emergency(path)['紧急购电量'].sum()/1000
    summary.append((name,cost,em))
sumdf=pd.DataFrame(summary,columns=['方案','正常购电费用','紧急购电量'])
fig=plt.figure(figsize=(7.1,5.55)); gs=fig.add_gridspec(2,2,hspace=.42,wspace=.34)
a=fig.add_subplot(gs[0,:]); style(a); panel(a,'(a)')
a.plot(x,q42[i42],color=C['midblue'],label='Q4-2 正常购电')
a.plot(x,q43[i43],color=C['rose'],label='Q4-3 最终正常购电')
a.set_xlim(0,24); a.set_xticks([0,4,8,12,16,20,24]); a.set_xlabel('时刻 / h'); a.set_ylabel('购电量 / (kWh/10 min)')
a2=a.twinx(); a2.plot(x,price4,color=C['deep'],ls='--',lw=1.05,label='事后真实动态电价'); a2.set_ylabel('电价 / (元·kWh$^{-1}$)'); a2.spines['top'].set_visible(False)
h1,l1=a.get_legend_handles_labels(); h2,l2=a2.get_legend_handles_labels(); a.legend(h1+h2,l1+l2,frameon=False,ncol=3,loc='upper center')
a=fig.add_subplot(gs[1,0]); style(a); panel(a,'(b)')
xx=np.arange(4); a.bar(xx,sumdf['正常购电费用'],color=[C['midblue'],C['orange'],C['slate'],C['rose']],width=.65); a.set_xticks(xx); a.set_xticklabels(sumdf['方案']); a.set_ylabel('正常购电费用 / 万元')
for xi,v in zip(xx,sumdf['正常购电费用']): a.text(xi,v+8,f'{v:.1f}',ha='center',va='bottom',fontsize=6.8)
a=fig.add_subplot(gs[1,1]); style(a); panel(a,'(c)')
a.bar(xx,sumdf['紧急购电量'],color=[C['midblue'],C['orange'],C['slate'],C['rose']],width=.65); a.set_xticks(xx); a.set_xticklabels(sumdf['方案']); a.set_ylabel('紧急购电量 / MWh')
for xi,v in zip(xx,sumdf['紧急购电量']): a.text(xi,v+3,f'{v:.1f}',ha='center',va='bottom',fontsize=6.8)
save(fig,'q4_dynamic')

print('Figures rebuilt from final input/result files using', FONT)
