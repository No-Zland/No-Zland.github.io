# -*- coding: utf-8 -*-
"""
analysis_cost_summary.py
从已经完成的 period.pkl 直接汇总 Q2/Q3/Q4 的真实费用分解。

本脚本不重新优化，只读取正式运行结果对象中的逐日费用字段，
因此不会根据 Excel 长表反推紧急购电费用。

运行：
    python analysis_cost_summary.py \
        --model-dir models \
        --out output/diagnostics/cost_summary.csv
"""

from __future__ import annotations

import argparse
import pickle
from pathlib import Path

import pandas as pd


def _load(path: Path):
    with path.open("rb") as f:
        return pickle.load(f)


def summarize_q2(period) -> dict:
    days = list(period.formal_results.values())
    regular = sum(float(d.plan_cost_yuan) for d in days)
    emergency = sum(float(d.emergency_cost_yuan) for d in days)
    total = sum(float(d.total_cost_yuan) for d in days)
    return {
        "方案": "Q2",
        "正常购电结算费用_元": regular,
        "紧急购电费用_元": emergency,
        "总运行费用_元": total,
    }


def summarize_q3_like(name: str, period) -> dict:
    days = list(period.formal_results.values())
    regular = sum(float(d.C_reg_yuan) for d in days)
    emergency = sum(float(d.C_emg_yuan) for d in days)
    total = sum(float(d.C_total_yuan) for d in days)
    plan = sum(float(d.C_plan_yuan) for d in days)
    adjustment = sum(float(d.C_adj_yuan) for d in days)
    return {
        "方案": name,
        "原计划费用_元": plan,
        "调整费用_元": adjustment,
        "正常购电结算费用_元": regular,
        "紧急购电费用_元": emergency,
        "总运行费用_元": total,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", type=Path, default=Path("models"))
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("output/diagnostics/cost_summary.csv"),
    )
    args = parser.parse_args()

    q2 = _load(args.model_dir / "q2_period.pkl")
    q3 = _load(args.model_dir / "q3_period.pkl")
    q42 = _load(args.model_dir / "q4_2_period.pkl")
    q43 = _load(args.model_dir / "q4_3_period.pkl")

    rows = [
        summarize_q2(q2),
        summarize_q3_like("Q3", q3),
        summarize_q3_like("Q4-2", q42),
        summarize_q3_like("Q4-3", q43),
    ]
    frame = pd.DataFrame(rows)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.out, index=False, encoding="utf-8-sig")
    print(frame.to_string(index=False))


if __name__ == "__main__":
    main()
