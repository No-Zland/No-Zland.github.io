# -*- coding: utf-8 -*-
"""
review_audit.py
评审意见对应的可复现审计脚本。

用途：
1. 检查 Q3/Q4-3 的附件3发布时间映射是否严格为 0/6/12/18 点；
2. 检查物理 k、业务槽位和正式输出时间标签是否一致；
3. 检查 result_writer 默认不会把“3行示例”误当成每日最多3段；
4. 可选：核对官方模板与正式结果的工作表结构，并验证结果时间表头已修正为物理区间。

运行：
    python review_audit.py
    python review_audit.py --template-dir data/template --result-dir output/results
"""

from __future__ import annotations

import argparse
import inspect
from pathlib import Path

import pandas as pd

from config import DEFAULT_CONFIG
from rolling_scheduler import UPDATE_K, run_settlement_self_tests
from time_index import build_time_map
import result_writer


def check_issue_mapping() -> list[dict]:
    rows = []
    date = pd.Timestamp("2025-01-01")
    for r, hour in zip(UPDATE_K, (0, 6, 12, 18)):
        issue = date + pd.Timedelta(
            minutes=int(r) * int(DEFAULT_CONFIG.dt_minutes)
        )
        expected = date + pd.Timedelta(hours=hour)
        rows.append(
            {
                "item": f"issue_r_{r}",
                "passed": issue == expected,
                "detail": f"{issue} == {expected}",
            }
        )
    return rows


def check_time_map() -> list[dict]:
    tm = build_time_map(DEFAULT_CONFIG).set_index("k")
    expected = {
        0: ("0:00-0:10", "0:00-0:10"),
        41: ("6:50-7:00", "6:50-7:00"),
        60: ("10:00-10:10", "10:00-10:10"),
        143: ("23:50-24:00", "23:50-24:00"),
    }
    rows = []
    for k, (physical, template) in expected.items():
        got_physical = tm.loc[k, "paper_label"]
        got_template = tm.loc[k, "template_display_label"]
        rows.append(
            {
                "item": f"time_k_{k}",
                "passed": (
                    got_physical == physical
                    and got_template == template
                    and int(tm.loc[k, "template_slot"]) == k
                ),
                "detail": (
                    f"physical={got_physical}; "
                    f"template={got_template}; "
                    f"slot={tm.loc[k, 'template_slot']}"
                ),
            }
        )
    return rows


def check_writer_defaults() -> list[dict]:
    funcs = [
        result_writer.write_result2,
        result_writer.write_result3,
        result_writer.write_result4_2,
        result_writer.write_result4_3,
        result_writer.write_all_results,
    ]
    rows = []
    for func in funcs:
        default = inspect.signature(func).parameters[
            "strict_max_three_events"
        ].default
        rows.append(
            {
                "item": f"{func.__name__}:strict_default_false",
                "passed": default is False,
                "detail": f"default={default!r}",
            }
        )
    return rows


def compare_template_headers(
    template_dir: Path,
    result_dir: Path,
) -> list[dict]:
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise RuntimeError(
            "模板逐列核验需要 openpyxl。"
        ) from exc

    rows = []
    for filename in (
        "result2.xlsx",
        "result3.xlsx",
        "result4-2.xlsx",
        "result4-3.xlsx",
    ):
        template_path = template_dir / filename
        result_path = result_dir / filename
        if not template_path.exists() or not result_path.exists():
            rows.append(
                {
                    "item": f"{filename}:files_exist",
                    "passed": False,
                    "detail": (
                        f"template={template_path.exists()}, "
                        f"result={result_path.exists()}"
                    ),
                }
            )
            continue

        twb = load_workbook(
            template_path,
            read_only=True,
            data_only=False,
        )
        rwb = load_workbook(
            result_path,
            read_only=True,
            data_only=False,
        )

        rows.append(
            {
                "item": f"{filename}:sheet_names",
                "passed": twb.sheetnames == rwb.sheetnames,
                "detail": (
                    f"template={twb.sheetnames}; "
                    f"result={rwb.sheetnames}"
                ),
            }
        )

        for sheet_name in ("计划购电量", "调整购电量"):
            if sheet_name not in twb.sheetnames:
                continue
            tws = twb[sheet_name]
            rws = rwb[sheet_name]

            template_header = [
                tws.cell(1, c).value
                for c in range(1, tws.max_column + 1)
            ]
            result_header = [
                rws.cell(1, c).value
                for c in range(1, tws.max_column + 1)
            ]
            # 官方空白模板的时间显示文字可能存在10 min偏移；
            # 正式结果保留相同槽位数量和非时间字段，但时间表头统一
            # 改写为真实物理区间，不要求与异常显示文字逐字相同。
            corrected = build_time_map(DEFAULT_CONFIG)[
                "template_display_label"
            ].tolist()
            same_shape = tws.max_column == rws.max_column
            same_non_time_tail = (
                template_header[145:] == result_header[145:]
                if len(template_header) >= 147 and len(result_header) >= 147
                else True
            )
            rows.append(
                {
                    "item": f"{filename}:{sheet_name}:structure",
                    "passed": bool(same_shape and same_non_time_tail),
                    "detail": (
                        f"columns(template/result)={tws.max_column}/{rws.max_column}; "
                        f"tail_match={same_non_time_tail}"
                    ),
                }
            )
            rows.append(
                {
                    "item": f"{filename}:{sheet_name}:physical_time_headers",
                    "passed": result_header[1:145] == corrected,
                    "detail": (
                        f"result_first={result_header[1]!r}; "
                        f"result_k60={result_header[61]!r}; "
                        f"result_last={result_header[144]!r}"
                    ),
                }
            )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--template-dir",
        type=Path,
        default=None,
    )
    parser.add_argument(
        "--result-dir",
        type=Path,
        default=None,
    )
    parser.add_argument(
        "--csv",
        type=Path,
        default=Path("output/diagnostics/review_audit.csv"),
    )
    args = parser.parse_args()

    rows = []
    rows += check_issue_mapping()
    rows += check_time_map()
    rows += check_writer_defaults()

    settlement = run_settlement_self_tests()
    for _, row in settlement.iterrows():
        rows.append(
            {
                "item": f"settlement:{row['test']}",
                "passed": bool(row["passed"]),
                "detail": (
                    f"actual={row['actual']}; "
                    f"expected={row['expected']}"
                ),
            }
        )

    if args.template_dir is not None and args.result_dir is not None:
        rows += compare_template_headers(
            args.template_dir,
            args.result_dir,
        )

    report = pd.DataFrame(rows)
    args.csv.parent.mkdir(parents=True, exist_ok=True)
    report.to_csv(args.csv, index=False, encoding="utf-8-sig")

    print(report.to_string(index=False))
    if not report["passed"].all():
        raise SystemExit("REVIEW AUDIT FAILED")
    print("REVIEW AUDIT PASSED")


if __name__ == "__main__":
    main()
