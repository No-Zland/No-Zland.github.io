# -*- coding: utf-8 -*-
"""
analysis_settlement_sensitivity.py
Q3/Q4-3 调整费用结算口径敏感性。

目的：
比较同一组已经求得的滚动计划版本在两种“计费解释”下的费用：
A. 正式主假设：最终计划 GF 相对 0:00 原计划 G0 一次净结算；
B. 逐次结算：6:00/12:00/18:00 每次新计划相对上一版有效计划结算。

注意：
本脚本属于“固定计划版本的结算口径敏感性”，不重新优化滚动计划。
若要研究不同结算规则对最优策略本身的影响，应另行修改目标函数并
重新运行 Q3/Q4-3。论文中必须明确区分这两层含义。

运行：
    python analysis_settlement_sensitivity.py \
        --model-dir models \
        --data-dir data \
        --out output/diagnostics/settlement_sensitivity.csv
"""

from __future__ import annotations

import argparse
import pickle
from pathlib import Path

import pandas as pd

from config import ProjectConfig
from data_loader import load_attachment1


def _load(path: Path):
    with path.open("rb") as f:
        return pickle.load(f)


def sequential_regular_cost(
    *,
    original_plan: pd.Series,
    plan_versions: dict[int, pd.Series],
    price: pd.Series,
) -> tuple[float, float, float]:
    """
    返回 (C_plan, C_adj_seq, C_reg_seq)。

    对每次 r>0 更新，仅对尚未执行的 k>=r 与上一版计划之间的差额收费。
    """
    G0 = original_plan.astype(float).copy()
    current = G0.copy()
    price = price.astype(float)

    expected = list(range(144))
    for series in (G0, price):
        if list(series.index) != expected:
            raise ValueError("结算输入必须严格使用 k=0..143。")

    C_plan = float((price * G0).sum())
    C_adj_seq = 0.0

    for r in sorted(int(x) for x in plan_versions):
        if r == 0:
            continue
        if r not in {36, 72, 108}:
            raise ValueError(f"发现非标准更新时间 r={r}")

        new = plan_versions[r].astype(float)
        if list(new.index) != expected:
            raise ValueError("plan_versions 必须保存完整144点快照。")

        if r > 0 and not new.loc[: r - 1].equals(current.loc[: r - 1]):
            # 允许极小浮点误差，使用差值再判断
            max_residual = float(
                (new.loc[: r - 1] - current.loc[: r - 1]).abs().max()
            )
            if max_residual > 1e-8:
                raise AssertionError(
                    f"r={r} 计划版本修改了已执行区间，"
                    f"max_residual={max_residual}"
                )

        idx = list(range(r, 144))
        delta = new.loc[idx] - current.loc[idx]
        up = delta.clip(lower=0.0)
        down = (-delta).clip(lower=0.0)

        C_adj_seq += float(
            (
                price.loc[idx]
                * (1.5 * up - 0.5 * down)
            ).sum()
        )
        current.loc[idx] = new.loc[idx]

    return C_plan, C_adj_seq, C_plan + C_adj_seq


def summarize_q3(period, fixed_price: pd.Series) -> dict:
    net_regular = 0.0
    sequential_regular = 0.0
    emergency = 0.0

    for day in period.formal_results.values():
        _, _, seq_reg = sequential_regular_cost(
            original_plan=day.original_plan_kwh,
            plan_versions=day.plan_versions,
            price=fixed_price,
        )
        net_regular += float(day.C_reg_yuan)
        sequential_regular += seq_reg
        emergency += float(day.C_emg_yuan)

    return {
        "方案": "Q3",
        "净结算正常购电费用_元": net_regular,
        "逐次结算正常购电费用_元": sequential_regular,
        "逐次相对净结算增量_元": sequential_regular - net_regular,
        "逐次相对净结算增幅_pct": (
            sequential_regular / net_regular - 1.0
        ) * 100.0,
        "紧急购电费用_元": emergency,
        "净结算总运行费用_元": net_regular + emergency,
        "逐次结算总运行费用_元": sequential_regular + emergency,
    }


def summarize_q43(period) -> dict:
    net_regular = 0.0
    sequential_regular = 0.0
    emergency = 0.0

    for day4 in period.formal_results.values():
        base = day4.base_result
        _, _, seq_reg = sequential_regular_cost(
            original_plan=base.original_plan_kwh,
            plan_versions=base.plan_versions,
            price=day4.actual_price_yuan_per_kwh,
        )
        net_regular += float(day4.C_reg_yuan)
        sequential_regular += seq_reg
        emergency += float(day4.C_emg_yuan)

    return {
        "方案": "Q4-3",
        "净结算正常购电费用_元": net_regular,
        "逐次结算正常购电费用_元": sequential_regular,
        "逐次相对净结算增量_元": sequential_regular - net_regular,
        "逐次相对净结算增幅_pct": (
            sequential_regular / net_regular - 1.0
        ) * 100.0,
        "紧急购电费用_元": emergency,
        "净结算总运行费用_元": net_regular + emergency,
        "逐次结算总运行费用_元": sequential_regular + emergency,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", type=Path, default=Path("models"))
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument(
        "--out",
        type=Path,
        default=Path(
            "output/diagnostics/settlement_sensitivity.csv"
        ),
    )
    args = parser.parse_args()

    config = ProjectConfig(data_dir=args.data_dir)
    attachment1 = load_attachment1(config)
    fixed_price = (
        attachment1.aligned["price_yuan_per_kwh"]
        .astype(float)
        .copy()
    )
    fixed_price.index = range(144)

    q3 = _load(args.model_dir / "q3_period.pkl")
    q43 = _load(args.model_dir / "q4_3_period.pkl")

    frame = pd.DataFrame(
        [
            summarize_q3(q3, fixed_price),
            summarize_q43(q43),
        ]
    )
    args.out.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.out, index=False, encoding="utf-8-sig")
    print(frame.to_string(index=False))


if __name__ == "__main__":
    main()
