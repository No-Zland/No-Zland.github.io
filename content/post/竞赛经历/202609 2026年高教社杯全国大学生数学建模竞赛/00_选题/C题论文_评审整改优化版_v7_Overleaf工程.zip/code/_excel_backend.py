# -*- coding: utf-8 -*-
"""
_excel_backend.py
openpyxl 实现的 artifact_tool 兼容适配层。

仅覆盖 src/result_writer.py 实际用到的 artifact_tool 接口：
    Workbook / SpreadsheetFile / Blob / Range / FreezePanes

目的是在不改动 result_writer.py 业务逻辑的前提下，用 openpyxl 完成
xlsx 的写出与回读校验。
"""

from __future__ import annotations

import json
import re
from typing import Any, Iterator

from openpyxl import Workbook as _PyWorkbook
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


_RANGE_RE = re.compile(
    r"^\s*([A-Za-z]+)(\d+)\s*:\s*([A-Za-z]+)(\d+)\s*$"
)


def _col_index(letters: str) -> int:
    n = 0
    for ch in letters.upper():
        n = n * 26 + (ord(ch) - ord("A") + 1)
    return n - 1


def _to_argb(color: Any) -> str | None:
    if color is None:
        return None
    color = str(color).strip()
    if color.startswith("#"):
        color = color[1:]
    if len(color) == 6:
        color = "FF" + color
    return color


class Blob:
    """兼容 artifact_tool.Blob 的最小实现。"""

    def __init__(self, path: str):
        self.path = path

    @staticmethod
    def load(path: str) -> "Blob":
        return Blob(path)


class _FormatProxy:
    def __init__(self, rng: "_Range"):
        object.__setattr__(self, "_rng", rng)

    def __setattr__(self, name: str, value: Any) -> None:
        if name == "_rng":
            object.__setattr__(self, name, value)
            return

        rng = self._rng
        if name == "column_width":
            rng._apply_column_width(value)
        else:
            rng._apply_cell_style(name, value)


class _Range:
    def __init__(
        self,
        ws: Any,
        start_row0: int,
        start_col0: int,
        row_count: int,
        col_count: int,
    ):
        self._ws = ws
        self._start_row0 = start_row0
        self._start_col0 = start_col0
        self._row_count = row_count
        self._col_count = col_count
        self._format_proxy = _FormatProxy(self)

    def _cells(self) -> Iterator[Any]:
        for i in range(self._row_count):
            for j in range(self._col_count):
                yield self._ws.cell(
                    row=self._start_row0 + 1 + i,
                    column=self._start_col0 + 1 + j,
                )

    @property
    def values(self) -> list[list[Any]]:
        out: list[list[Any]] = []
        for i in range(self._row_count):
            row: list[Any] = []
            for j in range(self._col_count):
                row.append(
                    self._ws.cell(
                        row=self._start_row0 + 1 + i,
                        column=self._start_col0 + 1 + j,
                    ).value
                )
            out.append(row)
        return out

    @values.setter
    def values(self, rows: list[list[Any]]) -> None:
        for i, row in enumerate(rows):
            for j, value in enumerate(row):
                self._ws.cell(
                    row=self._start_row0 + 1 + i,
                    column=self._start_col0 + 1 + j,
                    value=value,
                )

    @property
    def format(self) -> _FormatProxy:
        return self._format_proxy

    @format.setter
    def format(self, fmt_dict: dict) -> None:
        for key, value in fmt_dict.items():
            self._apply_cell_style(key, value)

    def _apply_cell_style(self, key: str, value: Any) -> None:
        for cell in self._cells():
            if key == "fill":
                color = _to_argb(value)
                cell.fill = PatternFill(
                    start_color=color,
                    end_color=color,
                    fill_type="solid",
                )
            elif key == "font":
                cell.font = (
                    Font(**value)
                    if isinstance(value, dict)
                    else value
                )
            elif key in (
                "horizontal_alignment",
                "vertical_alignment",
                "wrap_text",
            ):
                a = cell.alignment
                kwargs: dict[str, Any] = {}
                if a is not None:
                    kwargs["horizontal"] = a.horizontal
                    kwargs["vertical"] = a.vertical
                    kwargs["wrap_text"] = a.wrap_text

                if key == "horizontal_alignment":
                    kwargs["horizontal"] = value
                elif key == "vertical_alignment":
                    kwargs["vertical"] = value
                else:  # wrap_text
                    kwargs["wrap_text"] = value

                cell.alignment = Alignment(**kwargs)
            elif key == "number_format":
                cell.number_format = value
            else:
                raise ValueError(f"不支持的格式键：{key}")

    def _apply_column_width(self, value: Any) -> None:
        for j in range(self._col_count):
            letter = get_column_letter(self._start_col0 + 1 + j)
            self._ws.column_dimensions[letter].width = value


class _FreezePanes:
    def __init__(self, ws: Any):
        self._ws = ws
        self._rows = 0
        self._cols = 0

    def freeze_rows(self, n: int) -> None:
        self._rows = n
        self._apply()

    def freeze_columns(self, n: int) -> None:
        self._cols = n
        self._apply()

    def _apply(self) -> None:
        if self._rows or self._cols:
            self._ws.freeze_panes = (
                f"{get_column_letter(self._cols + 1)}"
                f"{self._rows + 1}"
            )
        else:
            self._ws.freeze_panes = None


class _Sheet:
    def __init__(self, ws: Any):
        self._ws = ws
        self.freeze_panes = _FreezePanes(ws)

    def get_range(self, a1: str) -> _Range:
        m = _RANGE_RE.match(a1)
        if not m:
            raise ValueError(f"非法A1范围：{a1}")

        c1, r1, c2, r2 = m.groups()
        start_col0 = _col_index(c1)
        end_col0 = _col_index(c2)
        start_row0 = int(r1) - 1
        end_row0 = int(r2) - 1

        row_count = end_row0 - start_row0 + 1
        col_count = end_col0 - start_col0 + 1

        if row_count <= 0 or col_count <= 0:
            raise ValueError(f"非法A1范围：{a1}")

        return _Range(
            self._ws,
            start_row0,
            start_col0,
            row_count,
            col_count,
        )


class _WorksheetCollection:
    def __init__(self, wb: Any):
        self._wb = wb

    def add(self, name: str) -> _Sheet:
        if name in self._wb.sheetnames:
            ws = self._wb[name]
        else:
            ws = self._wb.create_sheet(title=name)
        return _Sheet(ws)

    def get_item(self, name: str) -> _Sheet:
        return _Sheet(self._wb[name])


class _InspectResult:
    def __init__(self, ndjson: str):
        self.ndjson = ndjson


class Workbook:
    def __init__(self, wb: Any = None):
        self._wb = wb if wb is not None else _PyWorkbook()
        self.worksheets = _WorksheetCollection(self._wb)

    @staticmethod
    def create() -> "Workbook":
        wb = _PyWorkbook()
        default = wb.active
        if default is not None:
            wb.remove(default)
        return Workbook(wb)

    def inspect(self, spec: dict) -> _InspectResult:
        names = [ws.title for ws in self._wb.worksheets]
        lines = [
            json.dumps({"id": i, "name": name}, ensure_ascii=False)
            for i, name in enumerate(names)
        ]
        return _InspectResult("\n".join(lines))


class _ExportResult:
    def __init__(self, workbook: "Workbook"):
        self._workbook = workbook

    def save(self, path: str) -> None:
        self._workbook._wb.save(path)


class SpreadsheetFile:
    @staticmethod
    def export_xlsx(workbook: "Workbook") -> _ExportResult:
        return _ExportResult(workbook)

    @staticmethod
    def import_xlsx(blob: Blob) -> "Workbook":
        wb = load_workbook(blob.path)
        return Workbook(wb)
